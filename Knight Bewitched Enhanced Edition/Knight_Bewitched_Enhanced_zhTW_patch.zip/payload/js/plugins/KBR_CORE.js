
/*:
* @plugindesc include required image files

* @requiredAssets img/layers/DarkSpace3_mvt
* @requiredAssets img/layers/fog
* @requiredAssets img/layers/Fog_Black_mvt
* @requiredAssets img/layers/Fog_Green_mvt
* @requiredAssets img/layers/Fog_Blue_mvt
* @requiredAssets img/layers/Cloud2
* @requiredAssets img/layers/Fog1_mvt
* @requiredAssets img/layers/fog2
* @requiredAssets img/layers/fog3
* @requiredAssets img/layers/ShadowClouds
* @requiredAssets img/layers/LightClouds
* @requiredAssets img/layers/Space60
* @requiredAssets img/layers/Space80
* @requiredAssets img/layers/Space100
* @requiredAssets img/pictures/DisplacementMap

 */

var Imported = Imported || {};
Imported.KBR_CORE = true;

Window_Options.prototype.changePaintOpacity = function(enabled) {
    this.contents.paintOpacity = enabled ? 255 : 100;
};

//make poison damage KO enemies but not allies

_Game_Battler_maxSlipDamage = Game_Battler.prototype.maxSlipDamage;
Game_Battler.prototype.maxSlipDamage = function() {
    if (this.isEnemy()) return this.hp;
    return _Game_Battler_maxSlipDamage.apply(this);
};

//adjust status window for objective window

Scene_Menu.prototype.statusWindowRect = function() {
    const ww = Graphics.boxWidth - this.mainCommandWidth();
    const wh = this.mainAreaHeight() - 150;
    const wx = this.isRightInputMode() ? 0 : Graphics.boxWidth - ww;
    const wy = this.mainAreaTop();
    return new Rectangle(wx, wy, ww, wh);
};

Scene_Menu.prototype.create = function() {
    Scene_MenuBase.prototype.create.call(this);
    this.createCommandWindow();
    this.createGoldWindow();
    this.createStatusWindow();
    this.createObjectiveWindow();
};

Scene_Menu.prototype.createObjectiveWindow = function() {
    const rect = this.objectiveWindowRect();
    this._objectiveWindow = new Window_Objective(rect);
    this.addWindow(this._objectiveWindow);
};

Scene_Menu.prototype.objectiveWindowRect = function() {
    const ww = Graphics.boxWidth - this.mainCommandWidth();
    const wh = 150;
    const wx = this.isRightInputMode() ? 0 : Graphics.boxWidth - ww;
    const wy = 464;
    return new Rectangle(wx, wy, ww, wh);
};

//OBJECTIVE WINDOW

function Window_Objective() {
    this.initialize(...arguments);
};

Window_Objective.prototype = Object.create(Window_Base.prototype);
Window_Objective.prototype.constructor = Window_Objective;

Window_Objective.prototype.initialize = function(rect) {
    Window_Base.prototype.initialize.call(this, rect);
    this._text = '';
    this.refresh();

};

Window_Objective.prototype.clear = function() {
    this.setText('');
};

Window_Objective.prototype.refresh = function() {
    this.contents.clear();
    this.updateHelp();
    var x = this.itemPadding();
    var width = this.contents.width - this.itemPadding() * 2;
    var actor = $gameActors.actor($gameVariables.value(43));
    ImageManager.loadFace(actor.faceName());
    this.drawActorFace(actor, 5, 0, 128, 128);
    this.changeTextColor(ColorManager.textColor(6));
    this.drawText(actor.name() + ":", this.itemPadding() + 150, 0, width);
    //this.drawText("Current Objective:", this.itemPadding() + 160, 0, width, 'left');
    this.resetTextColor();
    this.drawTextEx(this._text, this.itemPadding() + 150, this.lineHeight());
};

Window_Objective.prototype.setText = function(text) {
    if (this._text !== text) {
        this._text = text;
        this.refresh();
    }
};

Window_Objective.prototype.open = function() {
    this.refresh();
    Window_Base.prototype.open.call(this);
};

Window_Objective.prototype.updateHelp = function() {
    this.setHelpWindowItem(this.item());
    
};

Window_Objective.prototype.setHelpWindowItem = function(item) {
    this.setItem(item);
};

Window_Objective.prototype.setItem = function(item) {
    this.setText(item ? item.description : '');
};

Window_Objective.prototype.setText = function(text) {
    if (this._text !== text) {
        this._text = text;
        this.refresh();

    }
};

Window_Objective.prototype.callUpdateHelp = function() {
    if (this.active && this._objectiveWindow) {
        this.updateHelp();
    }
};

Window_Objective.prototype.item = function() {
    var index = 59 + $gameVariables.value(42);
    return $dataItems[index];
};

Window_Base.prototype.drawActorFace = function(
    actor, x, y, width, height
) {
    this.drawFace(actor.faceName(), actor.faceIndex(), x, y, width, height);
};

//other stuff

Game_Player.prototype.performTransfer = function() {
    if (this.isTransferring()) {
        this.setDirection(this._newDirection);
        if (this._newMapId !== $gameMap.mapId() || this._needsMapReload) {
            $gameMap.setup(this._newMapId);
            this._needsMapReload = false;
        }
        this.locate(this._newX, this._newY);
        this.refresh();
        this.clearTransferInfo();
        $gameTemp.reserveCommonEvent(52);
};
}

//TP REGEN NO LONGER FUNCTIONS OUTSIDE OF COMBAT

Game_Battler.prototype.regenerateMp = function() {
    if ($gameParty.inBattle()) {
    const value = Math.floor(this.mmp * this.mrg);
    if (value !== 0) {
        this.gainMp(value);
    }
    }
};

Game_Player.prototype.encounterProgressValue = function() {
    let value = $gameMap.isBush(this.x, this.y) ? 1 : 1;
    if ($gameParty.hasEncounterHalf()) {
        value *= 0.5;
    }
    if (this.isInShip()) {
        value *= 0.5;
    }
    return value;
};

/*
Window_NameBox.prototype.start = function() {
    this.updatePlacement();
    //this.updateBackground();
    this.createContents();
    this.refresh();
    this.opacity = 0;
};



Window_Message.prototype.newLineX = function(textState) {
    const faceExists = $gameMessage.faceName() !== "";
    const faceWidth = ImageManager.faceWidth;
    const spacing = 20;
    const margin = faceExists ? faceWidth + spacing : 20;
    return textState.rtl ? this.innerWidth - margin : margin;
};

*/

Game_Vehicle.prototype.initMoveSpeed = function() {
    if (this.isBoat()) {
        this.setMoveSpeed(5);
    } else if (this.isShip()) {
        this.setMoveSpeed(5);
    } else if (this.isAirship()) {
        this.setMoveSpeed(6);
    }
};


Graphics._onKeyDown = function(event) {
    if (!event.ctrlKey && !event.altKey) {
        switch (event.keyCode) {
            case 113: // F2
                event.preventDefault();
                this._switchFPSCounter();
                break;
            case 118: // F7
                event.preventDefault();
                this._switchStretchMode();
                break;
            case 112: // F1
                event.preventDefault();
                this._switchFullScreen();
                break;
            case 192: // F1
                event.preventDefault();
                this._switchFullScreen();
                break;
        }
    }
};

Scene_Map.prototype.encounterEffectSpeed = function() {
    return 40;
};

Scene_Title.prototype.commandWindowRect = function() {
    const offsetX = $dataSystem.titleCommandWindow.offsetX;
    const offsetY = $dataSystem.titleCommandWindow.offsetY;
    const ww = this.mainCommandWidth();
    const wh = this.calcWindowHeight(4, true);
    const wx = (Graphics.boxWidth - ww) / 2 + offsetX;
    const wy = Graphics.boxHeight - wh - 96 + offsetY;
    return new Rectangle(wx, wy, ww, wh);
};

Window_PartyCommand.prototype.fontSize = function() {
 return 18;
};

Window_ActorCommand.prototype.fontSize = function() {
 return 18;
};

Window_Base.prototype.updateClose = function() {
    //original number is 32
    if (this._closing) {
        this.openness -= 37;
        if (this.isClosed()) {
            this._closing = false;
        }
    }
};

// Display the localized default name for actors restored from an English save.
(() => {
    const originalNames = {"1": "Ruth", "2": "Stray", "3": "Alduin", "4": "Uno", "5": "Gwen", "6": "CREDITS"};
    const actorName = Game_Actor.prototype.name;
    Game_Actor.prototype.name = function() {
        const name = actorName.apply(this, arguments);
        const actor = this.actor();
        if (actor && name === originalNames[actor.id]) {
            return actor.name;
        }
        return name;
    };
})();
